package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {
  
    private static Connection Conexion = null;
    
    public static Connection getConexion () throws SQLException, ClassNotFoundException{
    
        if(Conexion == null){
            
         try{
             Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
             Conexion = DriverManager.getConnection("jdbc:sqlserver://Royert-PC:1433;databaseName=Bd_Diablos");
             System.out.println("¡Conexion Exitosa!");
         }catch(SQLException ex){
             
             throw new SQLException(ex.getMessage());
             
             
         }catch(ClassNotFoundException ex){
              
             throw new ClassCastException(ex.getMessage());
             
         }   
            
        }
        return Conexion;
        
    }
    
    public static void Cerrar() throws SQLException{
        
        if(Conexion != null){
            
            Conexion.close();
            
        }
        
    }
}
