package MODELO;

public class Usuarios {
    
    
    private int uId;
    private String uCedula;
    private String uNombres;
    private String uApellidos;
    private String uDireccion;
    private String uGenero;
    private String uTelefono;
    private String uUser;
    private String uContraseña;

    
   
    public Usuarios(int uId, String uCedula, String uNombres, String uApellidos, String uDireccion, String uGenero, String uTelefono, String uUser, String uContraseña) {
        this.uId = uId;
        this.uCedula = uCedula;
        this.uNombres = uNombres;
        this.uApellidos = uApellidos;
        this.uDireccion = uDireccion;
        this.uGenero = uGenero;
        this.uTelefono = uTelefono;
        this.uUser = uUser;
        this.uContraseña = uContraseña;
    }

    public Usuarios(String uUser, String uContraseña) {
        this.uUser = uUser;
        this.uContraseña = uContraseña;
    }

    public Usuarios() {
    }

    public int getuId() {
        return uId;
    }

    public void setuId(int uId) {
        this.uId = uId;
    }

    public String getuCedula() {
        return uCedula;
    }

    public void setuCedula(String uCedula) {
        this.uCedula = uCedula;
    }

    public String getuNombres() {
        return uNombres;
    }

    public void setuNombres(String uNombres) {
        this.uNombres = uNombres;
    }

    public String getuApellidos() {
        return uApellidos;
    }

    public void setuApellidos(String uApellidos) {
        this.uApellidos = uApellidos;
    }

    public String getuDireccion() {
        return uDireccion;
    }

    public void setuDireccion(String uDireccion) {
        this.uDireccion = uDireccion;
    }

    public String getuGenero() {
        return uGenero;
    }

    public void setuGenero(String uGenero) {
        this.uGenero = uGenero;
    }

    public String getuTelefono() {
        return uTelefono;
    }

    public void setuTelefono(String uTelefono) {
        this.uTelefono = uTelefono;
    }

    public String getuUser() {
        return uUser;
    }

    public void setuUser(String uUser) {
        this.uUser = uUser;
    }

    public String getuContraseña() {
        return uContraseña;
    }

    public void setuContraseña(String uContraseña) {
        this.uContraseña = uContraseña;
    }
    
}
