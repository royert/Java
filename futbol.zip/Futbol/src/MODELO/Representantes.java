
package MODELO;


public class Representantes {
    
    private int IdRepresentante;  
    private String Cedula;           
    private String Nombres;          
    private String Apellidos;
    private String FechaNacimiento;  
    private String Genero;  
    private String Telefono;  

    public Representantes(int IdRepresentante, String Cedula, String Nombres, String Apellidos, String FechaNacimiento, String Genero, String Telefono) {
        this.IdRepresentante = IdRepresentante;
        this.Cedula = Cedula;
        this.Nombres = Nombres;
        this.Apellidos = Apellidos;
        this.FechaNacimiento = FechaNacimiento;
        this.Genero = Genero;
        this.Telefono = Telefono;
    }

    public int getIdRepresentante() {
        return IdRepresentante;
    }

    public void setIdRepresentante(int IdRepresentante) {
        this.IdRepresentante = IdRepresentante;
    }

    public String getCedula() {
        return Cedula;
    }

    public void setCedula(String Cedula) {
        this.Cedula = Cedula;
    }

    public String getNombres() {
        return Nombres;
    }

    public void setNombres(String Nombres) {
        this.Nombres = Nombres;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public String getFechaNacimiento() {
        return FechaNacimiento;
    }

    public void setFechaNacimiento(String FechaNacimiento) {
        this.FechaNacimiento = FechaNacimiento;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }
    
    
    
}
