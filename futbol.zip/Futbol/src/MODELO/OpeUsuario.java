package MODELO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;


public class OpeUsuario {
    
    public boolean Login(Connection conexion, Usuarios user) throws SQLException {
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_LOGIN(?)}");
            ps.setString(1, user.getuUser());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                if (user.getuContraseña().equals(rs.getString(9))) {

                    user.setuId(rs.getInt(1));
                    user.setuCedula(rs.getString(2));
                    user.setuNombres(rs.getString(3));
                    user.setuApellidos(rs.getString(4));
                    user.setuDireccion(rs.getString(5));
                    user.setuGenero(rs.getString(6));
                    user.setuTelefono(rs.getString(7));
                    return true;
                } else {
                    return false;
                }
            }
            return false;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return false;
        }
    }
    
}
