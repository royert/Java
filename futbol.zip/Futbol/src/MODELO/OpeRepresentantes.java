
package MODELO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;




public class OpeRepresentantes {
   
    public boolean GuardarRepresentantes(Connection conexion, Representantes re)throws SQLException{
        
        try {
            
            CallableStatement ps = conexion.prepareCall("{CALL PA_GUARDARREPRESENTANTE(?,?,?,?,?,?)}");
            ps.setInt(1, re.getIdRepresentante());
            ps.setString(2, re.getCedula());
            ps.setString(3, re.getNombres());
            ps.setString(4, re.getApellidos());
            ps.setString(5, re.getFechaNacimiento());
            ps.setString(6, re.getGenero());
            ps.setString(7, re.getTelefono());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return false;
        }
        
    }
    
      public boolean ModificarRepresentantes(Connection conexion, Representantes re)throws SQLException{
        
        try {
            
            CallableStatement ps = conexion.prepareCall("{CALL PA_MODIFICARREPRESENTANTE(?,?,?,?,?,?)}");
            ps.setInt(1, re.getIdRepresentante());
            ps.setString(2, re.getCedula());
            ps.setString(3, re.getNombres());
            ps.setString(4, re.getApellidos());
            ps.setString(5, re.getFechaNacimiento());
            ps.setString(6, re.getGenero());
            ps.setString(7, re.getTelefono());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return false;
        }
        
    }
    
     public boolean EliminarRepresentantes(Connection conexion, Representantes re)throws SQLException{
         
         try {
             
             CallableStatement ps = conexion.prepareCall("{CALL PA_ELIMINARREPRESENTANTE(?)}");
             ps.setString(2, re.getCedula());
             ps.executeUpdate();
             return true;
             
         } catch (SQLException e) {
             System.err.println(e.getMessage());
             return false;
         }
         
     }
      
     public int ExisteRepresentante(Connection conexion, String cedula) throws SQLException {
       try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_EXISTEJUGDOR(?)}");
            ps.setString(2, cedula + "");
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
            return 1;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return 1;
        }
    }
    
    public ArrayList<Representantes> MostrarTodo(Connection conexion) throws SQLException {
        ArrayList<Representantes> jug = new ArrayList<>();
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_MOSTRARTODO}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Representantes(rs.getInt("IdRepresentante"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono")));
            }
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }
        return jug;
    }
    
       public DefaultTableModel Mostrar(Connection conexion) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            ArrayList<Representantes> array = this.MostrarTodo(conexion);
            Object registro[] = new Object[8];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Representantes dato : array) {
                registro[0] = dato.getIdRepresentante();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
       public java.util.List<Representantes> BuscarXCedula(Connection conexion, String cedula) throws SQLException {
        List<Representantes> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Representantes(rs.getInt("IdRepresentante"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }
    
    public DefaultTableModel FiltroXCedula(Connection conexion, String cedula) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Representantes> array = this.BuscarXCedula(conexion, cedula);
            Object registro[] = new Object[8];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Representantes dato : array) {
                registro[0] = dato.getIdRepresentante();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Representantes> BuscarXNombres(Connection conexion, String nombre) throws SQLException {
        List<Representantes> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Representantes(rs.getInt("IdRepresentante"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }
    
    public DefaultTableModel FiltroXNombre(Connection conexion, String Nombre) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Representantes> array = this.BuscarXNombres(conexion, Nombre);
            Object registro[] = new Object[6];
            String[] titulos ={"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Representantes dato : array) {
                registro[0] = dato.getIdRepresentante();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Representantes> BuscarXApellidos(Connection conexion, String apellido) throws SQLException {
        List<Representantes> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Representantes(rs.getInt("IdRepresentante"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXApellidos(Connection conexion, String apellido) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Representantes> array = this.BuscarXApellidos(conexion, apellido);
            Object registro[] = new Object[6];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Representantes dato : array) {
                registro[0] = dato.getIdRepresentante();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Representantes> BuscarXGenero(Connection conexion, String genero) throws SQLException {
        List<Representantes> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGDOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Representantes(rs.getInt("IdRepresentante"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXGenero(Connection conexion, String genero) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Representantes> array = this.BuscarXGenero(conexion, genero);
            Object registro[] = new Object[6];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
             for (Representantes dato : array) {
                registro[0] = dato.getIdRepresentante();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Representantes> BuscarXTelefono(Connection conexion, String telefono) throws SQLException {
        List<Representantes> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Representantes(rs.getInt("IdRepresentante"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXTelefono(Connection conexion, String telefono) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Representantes> array = this.BuscarXTelefono(conexion, telefono);
            Object registro[] = new Object[6];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
             for (Representantes dato : array) {
                registro[0] = dato.getIdRepresentante();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Representantes> BuscarXFechaNacimiento(Connection conexion, String fechanacimiento) throws SQLException {
        List<Representantes> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Representantes(rs.getInt("IdRepresentante"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXFechaNacimiento(Connection conexion, String fechanacimiento) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Representantes> array = this.BuscarXFechaNacimiento(conexion, fechanacimiento);
            Object registro[] = new Object[6];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Representantes dato : array) {
                registro[0] = dato.getIdRepresentante();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    } 
}
