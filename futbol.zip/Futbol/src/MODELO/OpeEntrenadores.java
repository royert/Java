
package MODELO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;



public class OpeEntrenadores {
    

     public boolean GuardarEntrenador(Connection conexion, Entrenadores ent) throws SQLException {
 
        try {
                CallableStatement ps = conexion.prepareCall("{CALL PA_GUARDARENTRENADOR(?,?,?,?,?,?,?)}");
                ps.setInt(1, ent.getIdEntrenador());
                ps.setString(2, ent.getCedula());
                ps.setString(3, ent.getNombres());
                ps.setString(4, ent.getApellidos());
                ps.setString(5, ent.getDireccion());
                ps.setString(6, ent.getGenero());
                ps.setString(7, ent.getTelefono());
                ps.executeUpdate();
                return true;
        } catch (SQLException e) {
                System.err.println(e.getMessage());
                return false;
        }
    }
    
     public boolean ModificarEntrenador(Connection conexion, Entrenadores ent) throws SQLException {
        try {
             CallableStatement ps = conexion.prepareCall("{CALL PA_GUARDARENTRENADOR(?,?,?,?,?,?,?)}");
                ps.setInt(1, ent.getIdEntrenador());
                ps.setString(2, ent.getCedula());
                ps.setString(3, ent.getNombres());
                ps.setString(4, ent.getApellidos());
                ps.setString(5, ent.getDireccion());
                ps.setString(6, ent.getGenero());
                ps.setString(7, ent.getTelefono());
                ps.executeUpdate();
                return true;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return false;
        }
    }
    
     public boolean EliminarEntrenador(Connection conexion, Entrenadores ent){
         
         try {
             CallableStatement ps = conexion.prepareCall("{CALL PA_ELIMINARENTRENADOR(?)}");
             ps.setString(2, ent.getCedula());
             ps.executeUpdate();
             return true;
         } catch (SQLException e) {
             System.err.println(e.getMessage());
             return false;
         }
         
     }
     
     public ArrayList<Entrenadores> MostrarTodo(Connection conexion) throws SQLException {
        ArrayList<Entrenadores> ent = new ArrayList<>();
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_MOSTRARTODO}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ent.add(new Entrenadores(rs.getInt("IdEntrenador"),rs.getString("Cedula"), rs.getString("Nombre"), rs.getString("Apellidos"), rs.getString("Direccion"), rs.getString("Genero"), rs.getString("Telefono")));
            }
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }
        return ent;
    }

    public DefaultTableModel Mostrar(Connection conexion) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            ArrayList<Entrenadores> array = this.MostrarTodo(conexion);
            Object registro[] = new Object[6];
             String[] titulos = {"Id","Cedula","Nombres","Apellidos","Direccion","Genero","Telefono"};
            modelo.setColumnIdentifiers(titulos);
            for (Entrenadores dato : array) {
                registro[0] = dato.getIdEntrenador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getDireccion();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }

    public java.util.List<Entrenadores> BuscarXCedula(Connection conexion, String cedula) throws SQLException {
        List<Entrenadores> ent = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARENTRENADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ent.add(new Entrenadores(rs.getInt("IdEntrenador"),rs.getString("Cedula"), rs.getString("Nombre"), rs.getString("Apellidos"), rs.getString("Direccion"), rs.getString("Genero"), rs.getString("Telefono")));
            }
            return ent;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXCedula(Connection conexion, String cedula) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Entrenadores> array = this.BuscarXCedula(conexion, cedula);
            Object registro[] = new Object[6];
             String[] titulos = {"Id","Cedula","Nombres","Apellidos","Direccion","Genero","Telefono"};
            modelo.setColumnIdentifiers(titulos);
            for (Entrenadores dato : array) {
                registro[0] = dato.getIdEntrenador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getDireccion();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Entrenadores> BuscarXNombres(Connection conexion, String nombre) throws SQLException {
        List<Entrenadores> ent = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARENTRENADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ent.add(new Entrenadores(rs.getInt("IdEntrenador"),rs.getString("Cedula"), rs.getString("Nombre"), rs.getString("Apellidos"), rs.getString("Direccion"), rs.getString("Genero"), rs.getString("Telefono")));
            }
            return ent;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }
    
    public DefaultTableModel FiltroXNombre(Connection conexion, String Nombre) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Entrenadores> array = this.BuscarXNombres(conexion, Nombre);
            Object registro[] = new Object[6];
             String[] titulos = {"Id","Cedula","Nombres","Apellidos","Direccion","Genero","Telefono"};
            modelo.setColumnIdentifiers(titulos);
            for (Entrenadores dato : array) {
                registro[0] = dato.getIdEntrenador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getDireccion();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Entrenadores> BuscarXApellidos(Connection conexion, String apellido) throws SQLException {
        List<Entrenadores> ent = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARENTRENADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ent.add(new Entrenadores(rs.getInt("IdEntrenador"),rs.getString("Cedula"), rs.getString("Nombre"), rs.getString("Apellidos"), rs.getString("Direccion"), rs.getString("Genero"), rs.getString("Telefono")));
            }
            return ent;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXApellidos(Connection conexion, String apellido) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Entrenadores> array = this.BuscarXApellidos(conexion, apellido);
            Object registro[] = new Object[6];
             String[] titulos = {"Id","Cedula","Nombres","Apellidos","Direccion","Genero","Telefono"};
            modelo.setColumnIdentifiers(titulos);
            for (Entrenadores dato : array) {
                registro[0] = dato.getIdEntrenador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getDireccion();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Entrenadores> BuscarXGenero(Connection conexion, String genero) throws SQLException {
        List<Entrenadores> ent = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARENTRENADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ent.add(new Entrenadores(rs.getInt("IdEntrenador"),rs.getString("Cedula"), rs.getString("Nombre"), rs.getString("Apellidos"), rs.getString("Direccion"), rs.getString("Genero"), rs.getString("Telefono")));
            }
            return ent;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXGenero(Connection conexion, String genero) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Entrenadores> array = this.BuscarXGenero(conexion, genero);
            Object registro[] = new Object[6];
             String[] titulos = {"Id","Cedula","Nombres","Apellidos","Direccion","Genero","Telefono"};
            modelo.setColumnIdentifiers(titulos);
            for (Entrenadores dato : array) {
                registro[0] = dato.getIdEntrenador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getDireccion();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Entrenadores> BuscarXTelefono(Connection conexion, String telefono) throws SQLException {
        List<Entrenadores> ent = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARENTRENADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ent.add(new Entrenadores(rs.getInt("IdEntrenador"),rs.getString("Cedula"), rs.getString("Nombre"), rs.getString("Apellidos"), rs.getString("Direccion"), rs.getString("Genero"), rs.getString("Telefono")));
            }
            return ent;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXTelefono(Connection conexion, String telefono) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Entrenadores> array = this.BuscarXTelefono(conexion, telefono);
            Object registro[] = new Object[6];
             String[] titulos = {"Id","Cedula","Nombres","Apellidos","Direccion","Genero","Telefono"};
            modelo.setColumnIdentifiers(titulos);
            for (Entrenadores dato : array) {
                registro[0] = dato.getIdEntrenador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getDireccion();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Entrenadores> BuscarXEstado(Connection conexion, String estado) throws SQLException {
        List<Entrenadores> ent = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARENTRENADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ent.add(new Entrenadores(rs.getInt("IdEntrenador"),rs.getString("Cedula"), rs.getString("Nombre"), rs.getString("Apellidos"), rs.getString("Direccion"), rs.getString("Genero"), rs.getString("Telefono")));
            }
            return ent;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXEstado(Connection conexion, String estado) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Entrenadores> array = this.BuscarXEstado(conexion, estado);
            Object registro[] = new Object[6];
            String[] titulos = {"Id","Cedula","Nombres","Apellidos","Direccion","Genero","Telefono"};
            modelo.setColumnIdentifiers(titulos);
            for (Entrenadores dato : array) {
                registro[0] = dato.getIdEntrenador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getDireccion();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
     
}