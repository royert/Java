
package MODELO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;


public class OpeJugadores {

    public boolean GuardarJugador(Connection conexion, Jugadores jug) throws SQLException {
 
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_GUARDARJUGADOR(?,?,?,?,?,?,?,?)}");
            ps.setInt(1, jug.getIdJugador());
            ps.setString(2, jug.getCedula());
            ps.setString(3, jug.getNombres());
            ps.setString(4, jug.getApellidos());
            ps.setString(5, jug.getFechaNacimiento());
            ps.setString(6, jug.getGenero());
            ps.setString(7, jug.getTelefono());
            ps.setString(8, jug.getPosicion());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return false;
        }
    }
        
    public boolean ModificarJugador(Connection conexion, Jugadores jug){
        
        try {
            
            CallableStatement ps = conexion.prepareCall("{CALL PA_MODIFICARJUGADOR(?,?,?,?,?,?,?,?)}");
            ps.setInt(1, jug.getIdJugador());
            ps.setString(2, jug.getCedula());
            ps.setString(3, jug.getNombres());
            ps.setString(4, jug.getApellidos());
            ps.setString(5, jug.getFechaNacimiento());
            ps.setString(6, jug.getGenero());
            ps.setString(7, jug.getTelefono());
            ps.setString(8, jug.getPosicion());
            ps.executeUpdate();
            return true;
            
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return false;
        }
        
    }
    
    public boolean EliminarJugador(Connection conexion, Jugadores jug){
        
        try {
            
            CallableStatement ps = conexion.prepareCall("{CALL PA_ELIMINARJUGADOR(?)}");
            ps.setString(2, jug.getCedula());
            ps.executeUpdate();
            return true;
            
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return false;
        }  
    }
  
    public int ExisteJugador(Connection conexion, String cedula) throws SQLException {
       try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_EXISTEJUGDOR(?)}");
            ps.setString(2, cedula + "");
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
            return 1;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return 1;
        }
    }
    
    public ArrayList<Jugadores> MostrarTodo(Connection conexion) throws SQLException {
        ArrayList<Jugadores> jug = new ArrayList<>();
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_MOSTRARTODO}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Jugadores(rs.getInt("IdJugador"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono"), rs.getString("Posicion")));
            }
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }
        return jug;
    }
    
       public DefaultTableModel Mostrar(Connection conexion) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            ArrayList<Jugadores> array = this.MostrarTodo(conexion);
            Object registro[] = new Object[8];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Jugadores dato : array) {
                registro[0] = dato.getIdJugador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                registro[7] = dato.getPosicion();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
       public java.util.List<Jugadores> BuscarXCedula(Connection conexion, String cedula) throws SQLException {
        List<Jugadores> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Jugadores(rs.getInt("IdJugador"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono"), rs.getString("Posicion")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }
    
    public DefaultTableModel FiltroXCedula(Connection conexion, String cedula) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Jugadores> array = this.BuscarXCedula(conexion, cedula);
            Object registro[] = new Object[8];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Jugadores dato : array) {
                registro[0] = dato.getIdJugador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                registro[7] = dato.getPosicion();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Jugadores> BuscarXNombres(Connection conexion, String nombre) throws SQLException {
        List<Jugadores> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Jugadores(rs.getInt("IdJugador"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono"), rs.getString("Posicion")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }
    
    public DefaultTableModel FiltroXNombre(Connection conexion, String Nombre) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Jugadores> array = this.BuscarXNombres(conexion, Nombre);
            Object registro[] = new Object[6];
            String[] titulos ={"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Jugadores dato : array) {
            registro[0] = dato.getIdJugador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                registro[7] = dato.getPosicion();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Jugadores> BuscarXApellidos(Connection conexion, String apellido) throws SQLException {
        List<Jugadores> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Jugadores(rs.getInt("IdJugador"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono"), rs.getString("Posicion")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXApellidos(Connection conexion, String apellido) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Jugadores> array = this.BuscarXApellidos(conexion, apellido);
            Object registro[] = new Object[6];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Jugadores dato : array) {
                registro[0] = dato.getIdJugador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                registro[7] = dato.getPosicion();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Jugadores> BuscarXGenero(Connection conexion, String genero) throws SQLException {
        List<Jugadores> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGDOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Jugadores(rs.getInt("IdJugador"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono"), rs.getString("Posicion")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXGenero(Connection conexion, String genero) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Jugadores> array = this.BuscarXGenero(conexion, genero);
            Object registro[] = new Object[6];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Jugadores dato : array) {
                registro[0] = dato.getIdJugador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                registro[7] = dato.getPosicion();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Jugadores> BuscarXTelefono(Connection conexion, String telefono) throws SQLException {
        List<Jugadores> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Jugadores(rs.getInt("IdJugador"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono"), rs.getString("Posicion")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXTelefono(Connection conexion, String telefono) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Jugadores> array = this.BuscarXTelefono(conexion, telefono);
            Object registro[] = new Object[6];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Jugadores dato : array) {
               registro[0] = dato.getIdJugador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                registro[7] = dato.getPosicion();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Jugadores> BuscarXFechaNacimiento(Connection conexion, String fechanacimiento) throws SQLException {
        List<Jugadores> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Jugadores(rs.getInt("IdJugador"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono"), rs.getString("Posicion")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXFechaNacimiento(Connection conexion, String fechanacimiento) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Jugadores> array = this.BuscarXFechaNacimiento(conexion, fechanacimiento);
            Object registro[] = new Object[6];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Jugadores dato : array) {
                registro[0] = dato.getIdJugador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                registro[7] = dato.getPosicion();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public java.util.List<Jugadores> BuscarXPosicion(Connection conexion, String posicion) throws SQLException {
        List<Jugadores> jug = new ArrayList<>();
        
        try {
            CallableStatement ps = conexion.prepareCall("{CALL PA_BUSCARJUGADOR(?)}");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                jug.add(new Jugadores(rs.getInt("IdJugador"), rs.getString("Cedula"), rs.getString("Nombres"), rs.getString("Apellidos"), rs.getString("FechaNacimiento"), rs.getString("Genero"), rs.getString("Telefono"), rs.getString("Posicion")));
            }
            return jug;
        } catch (SQLException e) {
            throw new SQLException(e.getMessage());
        }

    }

    public DefaultTableModel FiltroXPosicion(Connection conexion, String posicion) {
        DefaultTableModel modelo = new DefaultTableModel();
        try {
            java.util.List<Jugadores> array = this.BuscarXPosicion(conexion, posicion);
            Object registro[] = new Object[6];
            String[] titulos = {"Id", "Cedula", "Nombre", "Apellidos", "FechaNacimiento", "Genero", "Telefono", "Posicion"};
            modelo.setColumnIdentifiers(titulos);
            for (Jugadores dato : array) {
               registro[0] = dato.getIdJugador();
                registro[1] = dato.getCedula();
                registro[2] = dato.getNombres();
                registro[3] = dato.getApellidos();
                registro[4] = dato.getFechaNacimiento();
                registro[5] = dato.getGenero();
                registro[6] = dato.getTelefono();
                registro[7] = dato.getPosicion();
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
       
}
    

