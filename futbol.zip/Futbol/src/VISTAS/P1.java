
package VISTAS;

import java.awt.Dimension;
import javax.swing.JInternalFrame;


public class P1 extends javax.swing.JFrame {

    
    public P1() {
        initComponents();
        
        this.setResizable(false);
        this.setExtendedState(MAXIMIZED_BOTH);
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        panelShadow1 = new org.edisoncor.gui.panel.PanelShadow();
        BotonAcceder = new javax.swing.JButton();
        BotonSalir = new javax.swing.JButton();
        Principal = new javax.swing.JDesktopPane();
        panel1 = new org.edisoncor.gui.panel.Panel();
        jLabel2 = new javax.swing.JLabel();
        panelShadow2 = new org.edisoncor.gui.panel.PanelShadow();
        btnJugadores = new javax.swing.JButton();
        btnEntrenadores = new javax.swing.JButton();
        btnConsultas = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGEN/1234567890.png"))); // NOI18N
        jLabel1.setToolTipText("");

        BotonAcceder.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        BotonAcceder.setForeground(new java.awt.Color(255, 255, 255));
        BotonAcceder.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGEN/acceso.png"))); // NOI18N
        BotonAcceder.setText("ACCEDER");
        BotonAcceder.setBorder(null);
        BotonAcceder.setBorderPainted(false);
        BotonAcceder.setContentAreaFilled(false);
        BotonAcceder.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BotonAcceder.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BotonAcceder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonAccederActionPerformed(evt);
            }
        });

        BotonSalir.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        BotonSalir.setForeground(new java.awt.Color(255, 255, 255));
        BotonSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGEN/exit.png"))); // NOI18N
        BotonSalir.setText("SALIR");
        BotonSalir.setBorder(null);
        BotonSalir.setBorderPainted(false);
        BotonSalir.setContentAreaFilled(false);
        BotonSalir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BotonSalir.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BotonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelShadow1Layout = new javax.swing.GroupLayout(panelShadow1);
        panelShadow1.setLayout(panelShadow1Layout);
        panelShadow1Layout.setHorizontalGroup(
            panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(BotonAcceder, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BotonSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelShadow1Layout.setVerticalGroup(
            panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BotonAcceder, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                    .addComponent(BotonSalir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setExtendedState(6);

        panel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGEN/photo_2021-02-12_21-28-46.jpg"))); // NOI18N

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGEN/1234567890.png"))); // NOI18N
        jLabel2.setToolTipText("");

        btnJugadores.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnJugadores.setForeground(new java.awt.Color(255, 255, 255));
        btnJugadores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGEN/football-player.png"))); // NOI18N
        btnJugadores.setText("JUGADORES");
        btnJugadores.setBorder(null);
        btnJugadores.setBorderPainted(false);
        btnJugadores.setContentAreaFilled(false);
        btnJugadores.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnJugadores.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnJugadores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJugadoresActionPerformed(evt);
            }
        });

        btnEntrenadores.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnEntrenadores.setForeground(new java.awt.Color(255, 255, 255));
        btnEntrenadores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGEN/coach.png"))); // NOI18N
        btnEntrenadores.setText("ENTRENADORES");
        btnEntrenadores.setBorder(null);
        btnEntrenadores.setBorderPainted(false);
        btnEntrenadores.setContentAreaFilled(false);
        btnEntrenadores.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEntrenadores.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEntrenadores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntrenadoresActionPerformed(evt);
            }
        });

        btnConsultas.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnConsultas.setForeground(new java.awt.Color(255, 255, 255));
        btnConsultas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGEN/refresh.png"))); // NOI18N
        btnConsultas.setText("CONSULTAS");
        btnConsultas.setBorder(null);
        btnConsultas.setBorderPainted(false);
        btnConsultas.setContentAreaFilled(false);
        btnConsultas.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnConsultas.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnConsultas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelShadow2Layout = new javax.swing.GroupLayout(panelShadow2);
        panelShadow2.setLayout(panelShadow2Layout);
        panelShadow2Layout.setHorizontalGroup(
            panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelShadow2Layout.createSequentialGroup()
                        .addGroup(panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnEntrenadores, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
                            .addComponent(btnJugadores, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(btnConsultas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panelShadow2Layout.setVerticalGroup(
            panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnJugadores)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnEntrenadores)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnConsultas)
                .addGap(155, 155, 155))
        );

        jLabel3.setFont(new java.awt.Font("Elephant", 1, 36)); // NOI18N
        jLabel3.setText("¡LOS MEJORES ENTRENAN");

        jLabel4.setFont(new java.awt.Font("Elephant", 1, 36)); // NOI18N
        jLabel4.setText("CON LOS MEJORES!");

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelShadow2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel2))
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 685, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(51, Short.MAX_VALUE))
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 271, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addGap(29, 29, 29))
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelShadow2, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Principal.setLayer(panel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout PrincipalLayout = new javax.swing.GroupLayout(Principal);
        Principal.setLayout(PrincipalLayout);
        PrincipalLayout.setHorizontalGroup(
            PrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        PrincipalLayout.setVerticalGroup(
            PrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Principal)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Principal)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BotonAccederActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonAccederActionPerformed

      

    }//GEN-LAST:event_BotonAccederActionPerformed

    private void BotonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_BotonSalirActionPerformed

    private void btnJugadoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJugadoresActionPerformed
        JUGADORES jg = new JUGADORES();
        CentrarVentana(jg);
        jg.setVisible(true);
    }//GEN-LAST:event_btnJugadoresActionPerformed

    private void btnEntrenadoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntrenadoresActionPerformed
        ENTRENADORES en = new ENTRENADORES();
        CentrarVentana(en);
        en.setVisible(true);
    }//GEN-LAST:event_btnEntrenadoresActionPerformed

    private void btnConsultasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultasActionPerformed
        CONSULTAS cs = new CONSULTAS();
        CentrarVentana(cs);
        cs.setVisible(true);
    }//GEN-LAST:event_btnConsultasActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonAcceder;
    private javax.swing.JButton BotonSalir;
    private javax.swing.JDesktopPane Principal;
    private javax.swing.JButton btnConsultas;
    private javax.swing.JButton btnEntrenadores;
    private javax.swing.JButton btnJugadores;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private org.edisoncor.gui.panel.Panel panel1;
    private org.edisoncor.gui.panel.PanelShadow panelShadow1;
    private org.edisoncor.gui.panel.PanelShadow panelShadow2;
    // End of variables declaration//GEN-END:variables

    //METODOS
    
      private void CentrarVentana(JInternalFrame frame) {
        Principal.add(frame);
        Dimension dimension = Principal.getSize();
        Dimension dframe = frame.getSize();
        frame.setLocation((dimension.width - dframe.width) / 2, (dimension.height - dframe.height) / 2);
    }

    
}
