
package VISTAS;

import MODELO.OpeJugadores;
import Modelo.Conexion;
import java.awt.Color;
import java.awt.HeadlessException;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class JUGADORES extends javax.swing.JInternalFrame {

    OpeJugadores opj = new OpeJugadores();
    private String accion = "Guardar";
    
    public JUGADORES() {
        initComponents();
        txtNombres.setEditable(false);
        txtApellidos.setEditable(false);
        txtCedula.setEditable(false);
        txtFechaNacimiento.setEditable(false);
        txtTelefono.setEditable(false);
        txtPosicion.setEditable(false);
        cboGenero.setEnabled(false);
        
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        panel1 = new org.edisoncor.gui.panel.Panel();
        panelRoundTranslucido2 = new org.edisoncor.gui.panel.PanelRoundTranslucido();
        txtFechaNacimiento = new org.edisoncor.gui.textField.TextFieldRoundIcon();
        txtApellidos = new org.edisoncor.gui.textField.TextFieldRoundIcon();
        txtNombres = new org.edisoncor.gui.textField.TextFieldRoundIcon();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtCedula = new org.edisoncor.gui.textField.TextFieldRoundIcon();
        jLabel13 = new javax.swing.JLabel();
        txtTelefono = new org.edisoncor.gui.textField.TextFieldRoundIcon();
        jLabel14 = new javax.swing.JLabel();
        cboGenero = new org.edisoncor.gui.comboBox.ComboBoxRound();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        txtPosicion = new org.edisoncor.gui.textField.TextFieldRoundIcon();
        botonRegistrar = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        botonNuevo = new javax.swing.JButton();
        botonCancelar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGEN/1234567890.png"))); // NOI18N
        jLabel1.setToolTipText("");

        panel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGEN/header-bg.jpg"))); // NOI18N

        panelRoundTranslucido2.setBackground(new java.awt.Color(255, 255, 255));
        panelRoundTranslucido2.setForeground(new java.awt.Color(255, 255, 255));
        panelRoundTranslucido2.setColorDeBorde(new java.awt.Color(255, 255, 255));
        panelRoundTranslucido2.setOpaque(false);

        txtFechaNacimiento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtFechaNacimientoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtFechaNacimientoKeyTyped(evt);
            }
        });

        txtApellidos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtApellidosKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtApellidosKeyTyped(evt);
            }
        });

        txtNombres.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombresKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombresKeyTyped(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Fecha/Nacimiento :");

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Nombres :");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Cedula :");

        txtCedula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCedulaKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCedulaKeyTyped(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Apellidos :");

        txtTelefono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTelefonoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTelefonoKeyTyped(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Telefono :");

        cboGenero.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Seleccionar", "Masculino", "Femenino" }));
        cboGenero.setToolTipText("");
        cboGenero.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboGeneroMouseClicked(evt);
            }
        });
        cboGenero.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cboGeneroKeyReleased(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Genero :");

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Posición :");

        txtPosicion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPosicionKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPosicionKeyTyped(evt);
            }
        });

        botonRegistrar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        botonRegistrar.setForeground(new java.awt.Color(255, 255, 255));
        botonRegistrar.setText("Registrar");
        botonRegistrar.setBorder(null);
        botonRegistrar.setBorderPainted(false);
        botonRegistrar.setContentAreaFilled(false);
        botonRegistrar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        botonRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarActionPerformed(evt);
            }
        });

        botonNuevo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        botonNuevo.setForeground(new java.awt.Color(255, 255, 255));
        botonNuevo.setText("Nuevo");
        botonNuevo.setBorder(null);
        botonNuevo.setBorderPainted(false);
        botonNuevo.setContentAreaFilled(false);
        botonNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonNuevoActionPerformed(evt);
            }
        });

        botonCancelar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        botonCancelar.setForeground(new java.awt.Color(255, 255, 255));
        botonCancelar.setText("Cancelar");
        botonCancelar.setBorder(null);
        botonCancelar.setBorderPainted(false);
        botonCancelar.setContentAreaFilled(false);
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelRoundTranslucido2Layout = new javax.swing.GroupLayout(panelRoundTranslucido2);
        panelRoundTranslucido2.setLayout(panelRoundTranslucido2Layout);
        panelRoundTranslucido2Layout.setHorizontalGroup(
            panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelRoundTranslucido2Layout.createSequentialGroup()
                            .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel14)
                                .addComponent(jLabel15))
                            .addGap(20, 20, 20)
                            .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(cboGenero, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelRoundTranslucido2Layout.createSequentialGroup()
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(txtPosicion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(18, 18, 18)
                        .addComponent(txtApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(txtFechaNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtNombres, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGap(32, 32, 32)
                        .addComponent(txtCedula, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jLabel17))
                    .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(botonCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(69, Short.MAX_VALUE))
        );
        panelRoundTranslucido2Layout.setVerticalGroup(
            panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel12))
                            .addComponent(txtCedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel11))
                            .addComponent(txtNombres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel13))
                            .addComponent(txtApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel10))
                            .addComponent(txtFechaNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cboGenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15))
                        .addGap(20, 20, 20)
                        .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel14))
                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelRoundTranslucido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(txtPosicion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelRoundTranslucido2Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botonNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGEN/1234567890.png"))); // NOI18N

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelRoundTranslucido2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addContainerGap())
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelRoundTranslucido2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(59, 59, 59))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtFechaNacimientoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtFechaNacimientoKeyReleased
        txtFechaNacimiento.setBackground(Color.WHITE);
    }//GEN-LAST:event_txtFechaNacimientoKeyReleased

    private void txtFechaNacimientoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtFechaNacimientoKeyTyped
        char numero = evt.getKeyChar();
        if (Character.isLetter(numero)) {
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, "¡DEBE INGRESAR SOLO NUMEROS!", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
        }
        if (txtFechaNacimiento.getText().length() == 11) {
            evt.consume();
            getToolkit().beep();
        }
    }//GEN-LAST:event_txtFechaNacimientoKeyTyped

    private void txtApellidosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApellidosKeyReleased
        txtApellidos.setBackground(Color.WHITE);
    }//GEN-LAST:event_txtApellidosKeyReleased

    private void txtApellidosKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApellidosKeyTyped
        char letra = evt.getKeyChar();
        if (Character.isDigit(letra)) {
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, "¡DEBE INGRESAR SOLO LETRAS!", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
        }
        if(txtApellidos.getText().length() == 100){
            
            getToolkit().beep();
            evt.consume();
            
        }
    }//GEN-LAST:event_txtApellidosKeyTyped

    private void txtNombresKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombresKeyReleased
        txtNombres.setBackground(Color.WHITE);
    }//GEN-LAST:event_txtNombresKeyReleased

    private void txtNombresKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombresKeyTyped
        char letra = evt.getKeyChar();
        if (Character.isDigit(letra)) {
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, "¡DEBE INGRESAR SOLO LETRAS!", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
        }
        if(txtNombres.getText().length() == 100){
            
            getToolkit().beep();
            evt.consume();
            
        }
    }//GEN-LAST:event_txtNombresKeyTyped

    private void txtCedulaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCedulaKeyReleased
        txtCedula.setBackground(Color.WHITE);
    }//GEN-LAST:event_txtCedulaKeyReleased

    private void txtTelefonoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTelefonoKeyReleased
        txtTelefono.setBackground(Color.WHITE);
    }//GEN-LAST:event_txtTelefonoKeyReleased

    private void txtTelefonoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTelefonoKeyTyped
        char numero = evt.getKeyChar();
        if (Character.isLetter(numero)) {
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, "¡DEBE INGRESAR SOLO NUMEROS!", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
        }
        if (txtTelefono.getText().length() == 11) {
            evt.consume();
            getToolkit().beep();
        }
    }//GEN-LAST:event_txtTelefonoKeyTyped

    private void cboGeneroKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cboGeneroKeyReleased
        cboGenero.setBackground(Color.WHITE);
    }//GEN-LAST:event_cboGeneroKeyReleased

    private void txtPosicionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPosicionKeyReleased
        txtPosicion.setBackground(Color.WHITE);
    }//GEN-LAST:event_txtPosicionKeyReleased

    private void botonRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegistrarActionPerformed
        Guardar();
      
       
    }//GEN-LAST:event_botonRegistrarActionPerformed

    private void botonNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonNuevoActionPerformed
        botonRegistrar.setText("Guardar");
        accion = "Guardar";
        txtNombres.setEditable(true);
        txtApellidos.setEditable(true);
        txtCedula.setEditable(true);
        txtFechaNacimiento.setEditable(true);
        txtTelefono.setEditable(true);
        txtPosicion.setEditable(true);
        cboGenero.setEnabled(true);
        borrar();
    }//GEN-LAST:event_botonNuevoActionPerformed

    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarActionPerformed
        JOptionPane.showMessageDialog(null, "¡SE HA CANCELADO EL REGISTRO!","¡INFORME!",JOptionPane.INFORMATION_MESSAGE);
        borrar();
    }//GEN-LAST:event_botonCancelarActionPerformed

    private void txtCedulaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCedulaKeyTyped
         if(txtCedula.getText().length() == 20){
            
            getToolkit().beep();
            evt.consume();
        
        }
    }//GEN-LAST:event_txtCedulaKeyTyped

    private void cboGeneroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboGeneroMouseClicked
        cboGenero.setBackground(Color.white);
    }//GEN-LAST:event_cboGeneroMouseClicked

    private void txtPosicionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPosicionKeyTyped
        char letra = evt.getKeyChar();
        if(Character.isDigit(letra)){
            
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, "¡DEBES INGRESAR SOLO LETRAS!", "¡INFORMACION!", JOptionPane.INFORMATION_MESSAGE);
            
        }
    }//GEN-LAST:event_txtPosicionKeyTyped


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonCancelar;
    private javax.swing.JButton botonNuevo;
    private javax.swing.JButton botonRegistrar;
    private org.edisoncor.gui.comboBox.ComboBoxRound cboGenero;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private org.edisoncor.gui.panel.Panel panel1;
    private org.edisoncor.gui.panel.PanelRoundTranslucido panelRoundTranslucido2;
    private org.edisoncor.gui.textField.TextFieldRoundIcon txtApellidos;
    private org.edisoncor.gui.textField.TextFieldRoundIcon txtCedula;
    private org.edisoncor.gui.textField.TextFieldRoundIcon txtFechaNacimiento;
    private org.edisoncor.gui.textField.TextFieldRoundIcon txtNombres;
    private org.edisoncor.gui.textField.TextFieldRoundIcon txtPosicion;
    private org.edisoncor.gui.textField.TextFieldRoundIcon txtTelefono;
    // End of variables declaration//GEN-END:variables
    //METODOS
    
    public void borrar(){
        
        txtCedula.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        txtFechaNacimiento.setText("");
        txtPosicion.setText("");
        txtTelefono.setText("");
        cboGenero.setSelectedIndex(0);
        
    }

    private void MostrarTodo() {
        CONSULTAS cl = new CONSULTAS();
        try {
            DefaultTableModel modelo = this.opj.Mostrar(Conexion.getConexion());
            cl.tblJugadores.setModel(modelo);
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    private void Guardar() {

        if (accion.equals("Guardar")) {
            if (RevisarDatos() == false) {
                JOptionPane.showMessageDialog(null, "¡DEBE INGRESAR TODOS LOS CAMPOS!", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    MODELO.Jugadores jug = new MODELO.Jugadores(txtCedula.getText(),
                            txtNombres.getText(),
                            txtApellidos.getText(),
                            txtFechaNacimiento.getText(),
                            cboGenero.getSelectedItem().toString(),
                            txtTelefono.getText(),
                            txtPosicion.getText());
                    if (this.opj.ExisteJugador(Conexion.getConexion(), this.txtCedula.getText()) == 0) {
                        if (this.opj.GuardarJugador(Conexion.getConexion(), jug) == true) {

                            JOptionPane.showMessageDialog(null, "¡SE HA REGISTRADO CON EXITO!", "¡INFORME!", JOptionPane.INFORMATION_MESSAGE);
                            borrar();
                            MostrarTodo();

                        }
                    }
                } catch (ClassNotFoundException | SQLException e) {
                    System.err.println(e.getMessage());
                }
            }
        } else {
            if (accion.equals("Modificar")) {
                try {
                    MODELO.Jugadores jug = new MODELO.Jugadores(txtCedula.getText(),
                            txtNombres.getText(),
                            txtApellidos.getText(),
                            txtFechaNacimiento.getText(),
                            cboGenero.getSelectedItem().toString(),
                            txtTelefono.getText(),
                            txtPosicion.getText());
                           
                    if (this.opj.ModificarJugador(Conexion.getConexion(), jug) == true) {

                        JOptionPane.showConfirmDialog(null, "¡SE HA MODIFICADO CON EXITO!", "¡INFORME!", JOptionPane.INFORMATION_MESSAGE);
                        borrar();
                        MostrarTodo();

                    } else {
                        JOptionPane.showMessageDialog(null, "¡NO SE HA PODIDO MODIFICAR EL DATO!", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (ClassNotFoundException | SQLException e) {
                    System.err.println(e.getMessage());
                }
            }
        }

    }

     private boolean RevisarDatos() {

        if (txtCedula.getText().length() == 0) {
            txtCedula.setBackground(Color.RED);
            txtCedula.setText("");
            txtCedula.requestFocus();
            return false;
        } else if (txtNombres.getText().equals("")) {
            txtNombres.setBackground(Color.RED);
            txtNombres.setText("");
            txtNombres.requestFocus();
            return false;
        } else if (txtApellidos.getText().equals("")) {
            txtApellidos.setBackground(Color.RED);
            txtApellidos.setText("");
            txtApellidos.requestFocus();
            return false;
        } else if (txtFechaNacimiento.getText().equals("")) {
            txtFechaNacimiento.setBackground(Color.RED);
            txtFechaNacimiento.setText("");
            txtFechaNacimiento.requestFocus();
            return false;
        } else if (cboGenero.getSelectedIndex() == 0) {
            cboGenero.setBackground(Color.RED);
            cboGenero.setSelectedItem(0);
            return false;
        } else if (txtTelefono.getText().length() == 0) {
            txtTelefono.setBackground(Color.RED);
            txtTelefono.setText("");
            txtTelefono.requestFocus();
            return false;
        } else if (txtPosicion.getText().length() == 0) {
            txtPosicion.setBackground(Color.RED);
            txtPosicion.setText("");
            txtPosicion.requestFocus();
            return false;
        } 
        return true;
    }    
    
}
